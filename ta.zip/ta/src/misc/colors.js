export default {
  DARK: '#1e1e1e',
  LIGHT: '#FFF',
  HIJAU: '#b6d7a8',
  ERROR: '#ff0000',
};
