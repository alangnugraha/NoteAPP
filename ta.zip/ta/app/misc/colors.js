export default {
  GREEN: '#6f995e',
  LIGHT: '#FFF',
  HIJAU: '#b8d7ab',
  HITAM: '#000000',
};
